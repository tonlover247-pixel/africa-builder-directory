
import { Builder, Role, Ecosystem } from '../types';

const STORAGE_KEY = 'africa_builders_db';

const MOCK_BUILDERS: Builder[] = [
  {
    id: '1',
    name: 'Kofi Mensah',
    role: Role.DEVELOPER,
    country: 'Ghana',
    city: 'Accra',
    ecosystem: Ecosystem.SOLANA,
    projectName: 'Sika Protocol',
    bio: 'Building decentralized savings infrastructure for the African unbanked. Rust enthusiast and Solana developer since 2021.',
    skills: ['Rust', 'Solana', 'Typescript', 'Anchor'],
    website: 'https://sikaprotocol.io',
    twitter: 'kofimensah_sol',
    email: 'kofi@example.com',
    approved: true,
    featured: true,
    createdAt: new Date().toISOString(),
    avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Kofi'
  },
  {
    id: '2',
    name: 'Amina Okoro',
    role: Role.FOUNDER,
    country: 'Nigeria',
    city: 'Lagos',
    ecosystem: Ecosystem.MULTICHAIN,
    projectName: 'AfroPay',
    bio: 'Passionate about cross-border payments. CEO of AfroPay, a multicurrency settlement layer for SME merchants.',
    skills: ['Strategy', 'Fintech', 'React', 'Solidity'],
    website: 'https://afropay.network',
    twitter: 'amina_builds',
    email: 'amina@example.com',
    approved: true,
    featured: false,
    createdAt: new Date().toISOString(),
    avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Amina'
  }
];

export const getBuilders = (): Builder[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(MOCK_BUILDERS));
      return MOCK_BUILDERS;
    }
    return JSON.parse(stored);
  } catch (error) {
    console.error('Failed to load builders from storage:', error);
    // Return mock data as a fallback so the UI doesn't break
    return MOCK_BUILDERS;
  }
};

export const saveBuilder = (builder: Omit<Builder, 'id' | 'approved' | 'featured' | 'createdAt'>): Builder => {
  const builders = getBuilders();
  const newBuilder: Builder = {
    ...builder,
    id: crypto.randomUUID(), // Standardized unique IDs
    approved: false,
    featured: false,
    createdAt: new Date().toISOString(),
    avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(builder.name)}`
  };
  
  try {
    const updated = [...builders, newBuilder];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Failed to save to localStorage:', error);
    // In a real app, we might notify the user that storage is full
  }
  return newBuilder;
};

export const updateBuilderStatus = (id: string, updates: Partial<Builder>): Builder[] => {
  const builders = getBuilders();
  const updated = builders.map(b => b.id === id ? { ...b, ...updates } : b);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Failed to update localStorage:', error);
  }
  return updated;
};

export const deleteBuilder = (id: string): Builder[] => {
  const builders = getBuilders();
  const updated = builders.filter(b => b.id !== id);
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (error) {
    console.error('Failed to delete from localStorage:', error);
  }
  return updated;
};
