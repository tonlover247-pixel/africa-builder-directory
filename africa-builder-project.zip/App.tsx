
import React, { useState, useEffect, useMemo } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { Builder, Role, Ecosystem } from './types';
import { getBuilders, saveBuilder, updateBuilderStatus, deleteBuilder } from './services/storage';
import { Icons, AFRICAN_COUNTRIES } from './constants';
import { BuilderCard } from './components/BuilderCard';
import { ProfileModal } from './components/ProfileModal';

// Secure the secret key via environment variables
const ADMIN_SECRET = process.env.ADMIN_SECRET || 'admin';

// --- Home Component ---
const Home: React.FC<{ builders: Builder[]; onBuilderClick: (b: Builder) => void }> = ({ builders, onBuilderClick }) => {
  const spotlightBuilders = useMemo(() => builders.filter(b => b.approved && b.featured).slice(0, 3), [builders]);

  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative pt-20 pb-12 overflow-hidden">
        <div className="absolute top-0 right-0 -z-10 w-[50%] h-[100%] bg-emerald-500/5 blur-3xl rounded-full" />
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold uppercase tracking-widest border border-emerald-200">
              <span className="relative flex h-2 w-2" aria-hidden="true">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Empowering African Excellence
            </div>
            <h1 className="text-6xl md:text-7xl font-bold text-slate-900 leading-[1.1]">
              The Hub for <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">African Builders</span>
            </h1>
            <p className="text-xl text-slate-500 leading-relaxed max-w-xl">
              Discover, connect, and collaborate with the next generation of founders and developers building the future across the continent.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/directory" className="px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-600/20 active:scale-95 focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 outline-none">
                Explore Directory
              </Link>
              <Link to="/submit" className="px-8 py-4 bg-white text-slate-900 border border-slate-200 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all shadow-lg shadow-slate-200/50 active:scale-95 focus:ring-2 focus:ring-offset-2 focus:ring-slate-300 outline-none">
                Submit Profile
              </Link>
            </div>
          </div>
          <div className="hidden lg:block relative" aria-hidden="true">
            <div className="relative z-10 grid grid-cols-2 gap-6 rotate-3">
              <div className="bg-white p-6 rounded-3xl shadow-2xl mt-12 transform -translate-x-4 border border-slate-100">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center text-purple-600 mb-4">
                  <Icons.Star />
                </div>
                <h3 className="font-bold text-xl mb-2">Web3 Native</h3>
                <p className="text-slate-500 text-sm">Deeply rooted in Solana and Ethereum ecosystems across Africa.</p>
              </div>
              <div className="bg-emerald-600 p-6 rounded-3xl shadow-2xl text-white transform translate-y-4 border border-emerald-500">
                 <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center text-white mb-4">
                  <Icons.Globe />
                </div>
                <h3 className="font-bold text-xl mb-2">Verified Talent</h3>
                <p className="text-emerald-50/80 text-sm">Community-vetted profiles of founders, devs, and researchers.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Spotlight Section */}
      <section className="max-w-7xl mx-auto px-6">
        <div className="flex items-end justify-between mb-12">
          <div>
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Weekly Spotlight</h2>
            <p className="text-slate-500">Exceptional builders making waves in the ecosystem.</p>
          </div>
          <Link to="/directory" className="text-emerald-600 font-bold hover:underline mb-2 flex items-center gap-2 outline-none focus:ring-2 focus:ring-emerald-500 px-2 py-1 rounded-lg">
            View All Builders →
          </Link>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {spotlightBuilders.map(b => (
            <BuilderCard key={b.id} builder={b} onClick={onBuilderClick} />
          ))}
          {spotlightBuilders.length === 0 && (
            <div className="col-span-full py-20 text-center bg-slate-100 rounded-3xl border-2 border-dashed border-slate-200 text-slate-400">
              New spotlights coming soon!
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

// --- Directory Component ---
const Directory: React.FC<{ builders: Builder[]; onBuilderClick: (b: Builder) => void }> = ({ builders, onBuilderClick }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [countryFilter, setCountryFilter] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [ecoFilter, setEcoFilter] = useState('');

  const filteredBuilders = useMemo(() => {
    return builders.filter(b => {
      if (!b.approved) return false;
      const term = searchTerm.toLowerCase();
      const matchesSearch = b.name.toLowerCase().includes(term) || 
                            b.projectName.toLowerCase().includes(term) ||
                            b.skills.some(s => s.toLowerCase().includes(term));
      const matchesCountry = !countryFilter || b.country === countryFilter;
      const matchesRole = !roleFilter || b.role === roleFilter;
      const matchesEco = !ecoFilter || b.ecosystem === ecoFilter;
      return matchesSearch && matchesCountry && matchesRole && matchesEco;
    });
  }, [builders, searchTerm, countryFilter, roleFilter, ecoFilter]);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex flex-col lg:flex-row gap-12">
        <aside className="w-full lg:w-72 space-y-8">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm sticky top-24">
            <h3 className="font-bold text-lg mb-6 flex items-center gap-2">
              <Icons.Filter />
              Filters
            </h3>
            
            <div className="space-y-6">
              <div>
                <label htmlFor="search-input" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Search</label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-slate-400" aria-hidden="true"><Icons.Search /></span>
                  <input 
                    id="search-input"
                    type="text" 
                    placeholder="Name, project, or skill..."
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label htmlFor="country-select" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Country</label>
                <select 
                  id="country-select"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                  value={countryFilter}
                  onChange={e => setCountryFilter(e.target.value)}
                >
                  <option value="">All Countries</option>
                  {AFRICAN_COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>

              <div>
                <label htmlFor="role-select" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Role</label>
                <select 
                  id="role-select"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                  value={roleFilter}
                  onChange={e => setRoleFilter(e.target.value)}
                >
                  <option value="">All Roles</option>
                  {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>

              <div>
                <label htmlFor="eco-select" className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Ecosystem</label>
                <select 
                  id="eco-select"
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                  value={ecoFilter}
                  onChange={e => setEcoFilter(e.target.value)}
                >
                  <option value="">All Ecosystems</option>
                  {Object.values(Ecosystem).map(e => <option key={e} value={e}>{e}</option>)}
                </select>
              </div>

              <button 
                onClick={() => { setSearchTerm(''); setCountryFilter(''); setRoleFilter(''); setEcoFilter(''); }}
                className="w-full py-2 text-slate-500 text-sm font-semibold hover:text-emerald-600 transition-colors focus:outline-none focus:underline"
              >
                Clear All
              </button>
            </div>
          </div>
        </aside>

        <main className="flex-1">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-slate-900">
              {filteredBuilders.length} <span className="text-slate-400 font-medium">Builders Found</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredBuilders.map(b => (
              <BuilderCard key={b.id} builder={b} onClick={onBuilderClick} />
            ))}
            {filteredBuilders.length === 0 && (
              <div className="col-span-full py-32 text-center bg-white rounded-3xl border-2 border-dashed border-slate-200 space-y-4">
                <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
                  <Icons.Search />
                </div>
                <p className="text-slate-500 font-medium">No builders matched your current filters.</p>
                <button onClick={() => { setSearchTerm(''); setCountryFilter(''); setRoleFilter(''); setEcoFilter(''); }} className="text-emerald-600 font-bold focus:underline outline-none">Clear filters and try again</button>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

// --- Submit Component ---
const Submit: React.FC<{ onSubmit: (b: any) => void }> = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    name: '',
    role: Role.DEVELOPER,
    country: 'Nigeria',
    city: '',
    ecosystem: Ecosystem.SOLANA,
    projectName: '',
    bio: '',
    skills: '',
    website: '',
    twitter: '',
    email: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      skills: formData.skills.split(',').map(s => s.trim()).filter(s => s !== '')
    });
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto py-32 px-6 text-center space-y-6">
        <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce" aria-hidden="true">
          <Icons.Check />
        </div>
        <h2 className="text-4xl font-bold text-slate-900">Successfully Submitted!</h2>
        <p className="text-xl text-slate-500">Your profile has been sent to the admin team for approval.</p>
        <Link to="/" className="inline-block px-8 py-4 bg-emerald-600 text-white rounded-2xl font-bold focus:ring-2 focus:ring-emerald-500 outline-none">Return Home</Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-16 px-6">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Join the Directory</h1>
        <p className="text-slate-500">Share your journey and let the world know what you're building.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white p-8 md:p-12 rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-200/50 space-y-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label htmlFor="f-name" className="text-sm font-bold text-slate-700">Full Name *</label>
            <input id="f-name" required type="text" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="Kofi Mensah" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
          </div>
          <div className="space-y-2">
            <label htmlFor="f-email" className="text-sm font-bold text-slate-700">Email (Admin Use Only) *</label>
            <input id="f-email" required type="email" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="kofi@example.com" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} />
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label htmlFor="f-role" className="text-sm font-bold text-slate-700">Role *</label>
            <select id="f-role" required className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" value={formData.role} onChange={e => setFormData({...formData, role: e.target.value as Role})}>
              {Object.values(Role).map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label htmlFor="f-country" className="text-sm font-bold text-slate-700">Country *</label>
            <select id="f-country" required className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" value={formData.country} onChange={e => setFormData({...formData, country: e.target.value})}>
              {AFRICAN_COUNTRIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label htmlFor="f-eco" className="text-sm font-bold text-slate-700">Blockchain Ecosystem *</label>
            <select id="f-eco" required className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl" value={formData.ecosystem} onChange={e => setFormData({...formData, ecosystem: e.target.value as Ecosystem})}>
              {Object.values(Ecosystem).map(eco => <option key={eco} value={eco}>{eco}</option>)}
            </select>
          </div>
          <div className="space-y-2">
            <label htmlFor="f-project" className="text-sm font-bold text-slate-700">Project / Company Name *</label>
            <input id="f-project" required type="text" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="My Awesome DApp" value={formData.projectName} onChange={e => setFormData({...formData, projectName: e.target.value})} />
          </div>
        </div>

        <div className="space-y-2">
          <label htmlFor="f-bio" className="text-sm font-bold text-slate-700">Short Bio (Max 300 chars) *</label>
          <textarea id="f-bio" required maxLength={300} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl h-24 resize-none focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="Briefly describe what you're building..." value={formData.bio} onChange={e => setFormData({...formData, bio: e.target.value})} />
        </div>

        <div className="space-y-2">
          <label htmlFor="f-skills" className="text-sm font-bold text-slate-700">Skills (Comma separated) *</label>
          <input id="f-skills" required type="text" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="Rust, Solidity, Design, Python" value={formData.skills} onChange={e => setFormData({...formData, skills: e.target.value})} />
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label htmlFor="f-site" className="text-sm font-bold text-slate-700">Website URL *</label>
            <input id="f-site" required type="url" className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="https://project.com" value={formData.website} onChange={e => setFormData({...formData, website: e.target.value})} />
          </div>
          <div className="space-y-2">
            <label htmlFor="f-x" className="text-sm font-bold text-slate-700">Twitter Handle *</label>
            <div className="relative">
              <span className="absolute left-4 top-3.5 text-slate-400" aria-hidden="true">@</span>
              <input id="f-x" required type="text" className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" placeholder="handle" value={formData.twitter} onChange={e => setFormData({...formData, twitter: e.target.value})} />
            </div>
          </div>
        </div>

        <button type="submit" className="w-full py-5 bg-slate-900 text-white rounded-2xl font-bold text-xl hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10 active:scale-[0.98] focus:ring-2 focus:ring-slate-500 outline-none">
          Submit for Review
        </button>
      </form>
    </div>
  );
};

// --- Admin Component ---
const Admin: React.FC<{ 
  builders: Builder[]; 
  isAuthenticated: boolean;
  onAuthenticate: (pass: string) => void;
  onUpdate: (id: string, updates: Partial<Builder>) => void; 
  onDelete: (id: string) => void 
}> = ({ builders, isAuthenticated, onAuthenticate, onUpdate, onDelete }) => {
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved'>('all');
  const [passwordInput, setPasswordInput] = useState('');

  const filtered = builders.filter(b => {
    if (filter === 'pending') return !b.approved;
    if (filter === 'approved') return b.approved;
    return true;
  });

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto py-32 px-6">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-xl space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto text-slate-900 mb-4" aria-hidden="true">
              <Icons.Settings />
            </div>
            <h1 className="text-2xl font-bold">Admin Portal</h1>
            <p className="text-slate-500 text-sm">Please enter the administrative secret to continue.</p>
          </div>
          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="admin-pass" className="text-xs font-bold text-slate-400 uppercase">Secret Key</label>
              <input 
                id="admin-pass"
                type="password" 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500/20 outline-none" 
                placeholder="Enter secret..."
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && onAuthenticate(passwordInput)}
              />
            </div>
            <button 
              onClick={() => onAuthenticate(passwordInput)}
              className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all focus:ring-2 focus:ring-slate-500 outline-none"
            >
              Verify Identity
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-500">Review and manage builder submissions.</p>
        </div>
        <div className="flex gap-2 p-1 bg-slate-100 rounded-xl self-start md:self-center">
          {(['all', 'pending', 'approved'] as const).map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-1.5 rounded-lg text-sm font-bold capitalize transition-all focus:outline-none ${filter === f ? 'bg-white shadow text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl overflow-x-auto shadow-sm">
        <table className="w-full text-left min-w-[600px]">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Builder</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Project</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(b => (
              <tr key={b.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <img src={b.avatarUrl} className="w-10 h-10 rounded-lg bg-slate-100" alt="" />
                    <div>
                      <div className="font-bold text-slate-900">{b.name}</div>
                      <div className="text-xs text-slate-400">{b.role} • {b.country}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="font-medium text-slate-700">{b.projectName}</div>
                  <div className="text-xs text-slate-400">{b.ecosystem}</div>
                </td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${b.approved ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>
                    {b.approved ? 'Approved' : 'Pending'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-end gap-2">
                    {!b.approved && (
                      <button onClick={() => onUpdate(b.id, { approved: true })} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors focus:ring-2 focus:ring-emerald-500 outline-none" title="Approve">
                        <Icons.Check />
                      </button>
                    )}
                    {b.approved && (
                      <button onClick={() => onUpdate(b.id, { featured: !b.featured })} className={`p-2 rounded-lg transition-colors focus:ring-2 focus:ring-amber-500 outline-none ${b.featured ? 'text-amber-500 hover:bg-amber-50' : 'text-slate-300 hover:bg-slate-100'}`} title="Toggle Spotlight">
                        <Icons.Star />
                      </button>
                    )}
                    <button onClick={() => onDelete(b.id)} className="p-2 text-rose-600 hover:bg-rose-50 rounded-lg transition-colors focus:ring-2 focus:ring-rose-500 outline-none" title="Delete">
                      <Icons.Trash />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="py-20 text-center text-slate-400">No submissions found.</div>
        )}
      </div>
    </div>
  );
};

// --- Main App Component ---
const App: React.FC = () => {
  const [builders, setBuilders] = useState<Builder[]>([]);
  const [selectedBuilder, setSelectedBuilder] = useState<Builder | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setBuilders(getBuilders());
  }, []);

  const handleProfileSubmit = (data: any) => {
    const newBuilder = saveBuilder(data);
    // Optimized: Update local state directly instead of re-fetching everything
    setBuilders(prev => [...prev, newBuilder]);
  };

  const handleUpdate = (id: string, updates: Partial<Builder>) => {
    const updated = updateBuilderStatus(id, updates);
    setBuilders(updated);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this builder?')) {
      const updated = deleteBuilder(id);
      setBuilders(updated);
    }
  };

  const handleAuth = (pass: string) => {
    if (pass === ADMIN_SECRET) {
      setIsAuthenticated(true);
    } else {
      alert('Unauthorized access');
    }
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="flex flex-col min-h-screen">
      <nav className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group outline-none">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-emerald-600/20 group-hover:scale-105 transition-transform group-focus:ring-2 group-focus:ring-emerald-500">
              A
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-900">Africa<span className="text-emerald-600">Builder</span></span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <Link to="/directory" className={`font-semibold transition-colors outline-none focus:underline ${isActive('/directory') ? 'text-emerald-600' : 'text-slate-600 hover:text-emerald-600'}`}>Directory</Link>
            <Link to="/submit" className={`font-semibold transition-colors outline-none focus:underline ${isActive('/submit') ? 'text-emerald-600' : 'text-slate-600 hover:text-emerald-600'}`}>Join Hub</Link>
            <Link to="/admin" className={`p-2 transition-colors outline-none focus:ring-2 focus:ring-emerald-500 rounded-lg ${isActive('/admin') ? 'text-emerald-600' : 'text-slate-400 hover:text-slate-600'}`}>
              <Icons.Settings />
            </Link>
            <Link to="/submit" className="px-6 py-2.5 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all active:scale-95 focus:ring-2 focus:ring-offset-2 focus:ring-slate-500 outline-none">
              Get Started
            </Link>
          </div>

          <div className="md:hidden">
            <Link to="/admin" className="p-2 text-slate-600 outline-none focus:ring-2 focus:ring-emerald-500 rounded-lg"><Icons.Settings /></Link>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home builders={builders} onBuilderClick={setSelectedBuilder} />} />
          <Route path="/directory" element={<Directory builders={builders} onBuilderClick={setSelectedBuilder} />} />
          <Route path="/submit" element={<Submit onSubmit={handleProfileSubmit} />} />
          <Route path="/admin" element={<Admin builders={builders} isAuthenticated={isAuthenticated} onAuthenticate={handleAuth} onUpdate={handleUpdate} onDelete={handleDelete} />} />
        </Routes>
      </main>

      <footer className="bg-white border-t border-slate-100 py-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex flex-col items-center md:items-start gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">A</div>
              <span className="font-bold text-lg text-slate-900">AfricaBuilder Directory</span>
            </div>
            <p className="text-slate-400 text-sm">Building the future of African digital economy.</p>
          </div>
          <div className="flex gap-8 text-sm font-bold text-slate-400 uppercase tracking-widest">
            <Link to="/directory" className="hover:text-emerald-600 transition-colors focus:underline outline-none">Directory</Link>
            <Link to="/submit" className="hover:text-emerald-600 transition-colors focus:underline outline-none">Join</Link>
            <a href="#" className="hover:text-emerald-600 transition-colors focus:underline outline-none">Twitter</a>
          </div>
          <div className="text-slate-300 text-xs">
            © {new Date().getFullYear()} Africa Builder Hub.
          </div>
        </div>
      </footer>

      <ProfileModal builder={selectedBuilder} onClose={() => setSelectedBuilder(null)} />
    </div>
  );
};

export default App;
